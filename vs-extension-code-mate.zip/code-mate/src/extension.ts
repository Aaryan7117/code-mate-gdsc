import * as vscode from 'vscode';
import { spawn } from "child_process";

export function activate(context: vscode.ExtensionContext) {
    console.log('Code Mate is now active!');

    let panel: vscode.WebviewPanel | undefined;
    let chatHistory: { sender: string, text: string }[] = [];

    let disposable = vscode.commands.registerCommand('code-mate.runLlama', () => {
        if (!panel) {
            panel = vscode.window.createWebviewPanel(
                'codeMateChat',
                'Code Mate Chat',
                vscode.ViewColumn.Beside,
                { enableScripts: true }
            );

            panel.webview.onDidReceiveMessage((message) => {
                switch (message.command) {
                    case 'sendQuery':
                        handleQuery(message.text);
                        break;
                    case 'clearChat':
                        chatHistory = [];
                        updateWebview();
                        break;
                    case 'explainCode':
                        const editor = vscode.window.activeTextEditor;
                        if (!editor) {
                            vscode.window.showErrorMessage('No active file found. Open a file to explain its code.');
                            return;
                        }

                        const code = editor.document.getText(); // Get the entire code from the file
                        handleQuery(`Explain this code:\n\`\`\`\n${code}\n\`\`\``);
                        break;
                }
            }, undefined, context.subscriptions);

            panel.onDidDispose(() => { panel = undefined; }, null, context.subscriptions);
        }

        panel.webview.html = getWebviewContent(chatHistory);
    });

    let explainDisposable = vscode.commands.registerCommand('code-mate.explainCode', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active file found. Open a file to explain its code.');
            return;
        }

        const code = editor.document.getText(); // Get the entire code from the file
        handleQuery(`Explain this code:\n\`\`\`\n${code}\n\`\`\``);
    });

    context.subscriptions.push(disposable, explainDisposable);

    function handleQuery(userQuery: string) {
        if (!userQuery.trim()) { return; }

        // Add user message to chat history
        chatHistory.push({ sender: 'user', text: userQuery });
        updateWebview();

        // Show typing indicator
        if (panel) {
            panel.webview.postMessage({ command: 'showTypingIndicator' });
        }

        const ollama = spawn("ollama", ["run", "llama2"]);

        ollama.stdin.write(userQuery + "\n");
        ollama.stdin.end();

        let response = "";

        ollama.stdout.on("data", (data) => {
            response += data.toString();
        });

        ollama.stderr.on("data", (data) => {
            const cleanedError = stripAnsi(data.toString());
            console.error(cleanedError);
        });

        ollama.on("close", (code) => {
            if (code === 0) {
                const cleanedResponse = stripAnsi(response).trim();
                chatHistory.push({ sender: 'assistant', text: cleanedResponse });
            } else {
                chatHistory.push({ sender: 'error', text: `Ollama process exited with code ${code}` });
            }
            updateWebview();

            // Hide typing indicator
            if (panel) {
                panel.webview.postMessage({ command: 'hideTypingIndicator' });
            }
        });
    }

    function updateWebview() {
        if (panel) {
            panel.webview.html = getWebviewContent(chatHistory);
        }
    }

    function stripAnsi(text: string): string {
        return text.replace(
            // Regex to remove ANSI escape sequences (colors, cursor hiding, spinners, etc.)
            /[\u001b\u009b][[()#;?]*((\d{1,4}(;\d{0,4})*)?[0-9A-ORZcf-ntqry=><])/g,
            ""
        );
    }
}

export function deactivate() {}

function getWebviewContent(chatHistory: { sender: string, text: string }[]): string {
    return `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Code Mate Chat</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            <style>
                /* Full CSS from the updated design */
                :root {
                    --primary-color: #4f46e5;
                    --primary-light: #6366f1;
                    --bg-color: #ffffff;
                    --text-color: #333333;
                    --input-bg: #f5f7fa;
                    --chat-bg: #f9fafb;
                    --code-bg: #f1f5f9;
                    --border-color: #e5e7eb;
                    --shadow-color: rgba(0, 0, 0, 0.1);
                    --user-bubble: #e9f2ff;
                    --assistant-bubble: #f0f0f0;
                    --send-btn-hover: #4338ca;
                }
                
                [data-theme="dark"] {
                    --primary-color: #6366f1;
                    --primary-light: #818cf8;
                    --bg-color: #111827;
                    --text-color: #f3f4f6;
                    --input-bg: #1f2937;
                    --chat-bg: #1e293b;
                    --code-bg: #2d3748;
                    --border-color: #374151;
                    --shadow-color: rgba(0, 0, 0, 0.3);
                    --user-bubble: #3b4a69;
                    --assistant-bubble: #2a3441;
                    --send-btn-hover: #4f46e5;
                }
                
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: var(--bg-color);
                    color: var(--text-color);
                    height: 100vh;
                    display: flex;
                    flex-direction: column;
                    padding: 20px;
                }
                
                .header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 20px;
                    padding-bottom: 15px;
                    border-bottom: 1px solid var(--border-color);
                }
                
                .header h2 {
                    display: flex;
                    align-items: center;
                    font-weight: 600;
                    font-size: 1.5rem;
                }
                
                .header h2 i {
                    margin-right: 10px;
                    color: var(--primary-color);
                }
                
                .toggle-mode {
                    background: none;
                    border: none;
                    font-size: 1.5rem;
                    cursor: pointer;
                    color: var(--text-color);
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: var(--input-bg);
                    box-shadow: 0 2px 5px var(--shadow-color);
                }
                
                .toggle-mode:hover {
                    background: var(--primary-light);
                    color: white;
                }
                
                #chat-box {
                    flex: 1;
                    overflow-y: auto;
                    padding: 15px;
                    margin-bottom: 20px;
                    background: var(--chat-bg);
                    border-radius: 12px;
                    box-shadow: 0 4px 6px var(--shadow-color);
                    scroll-behavior: smooth;
                }
                
                .message {
                    margin-bottom: 15px;
                    max-width: 80%;
                    animation: fadeIn 0.3s ease-in-out;
                }
                
                .user-message {
                    margin-left: auto;
                    background: var(--user-bubble);
                    border-radius: 18px 18px 0 18px;
                    padding: 12px 15px;
                    color: var(--text-color);
                    align-self: flex-end;
                }
                
                .assistant-message {
                    margin-right: auto;
                    background: var(--assistant-bubble);
                    border-radius: 18px 18px 18px 0;
                    padding: 12px 15px;
                    color: var(--text-color);
                }
                
                .code-block {
                    background: var(--code-bg);
                    padding: 15px;
                    border-radius: 8px;
                    position: relative;
                    margin: 10px 0;
                    font-family: 'Courier New', monospace;
                    overflow-x: auto;
                    border-left: 3px solid var(--primary-color);
                }
                
                .copy-btn {
                    position: absolute;
                    top: 5px;
                    right: 5px;
                    background: var(--primary-color);
                    color: white;
                    border: none;
                    padding: 5px 10px;
                    cursor: pointer;
                    border-radius: 4px;
                    font-size: 0.8rem;
                    opacity: 0.8;
                    transition: opacity 0.2s;
                }
                
                .copy-btn:hover {
                    opacity: 1;
                }
                
                .input-container {
                    display: flex;
                    position: relative;
                    margin-bottom: 10px;
                }
                
                #query {
                    flex: 1;
                    padding: 15px 20px;
                    border-radius: 25px;
                    border: 1px solid var(--border-color);
                    background: var(--input-bg);
                    color: var(--text-color);
                    font-size: 1rem;
                    box-shadow: 0 2px 5px var(--shadow-color);
                    outline: none;
                }
                
                #query:focus {
                    border-color: var(--primary-color);
                    box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2);
                }
                
                .send-btn {
                    position: absolute;
                    right: 5px;
                    top: 50%;
                    transform: translateY(-50%);
                    background: var(--primary-color);
                    color: white;
                    border: none;
                    width: 45px;
                    height: 45px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                
                .send-btn:hover {
                    background: var(--send-btn-hover);
                    transform: translateY(-50%) scale(1.05);
                }
                
                .send-btn i {
                    font-size: 1.2rem;
                    transform: rotate(45deg);
                }
                
                .typing-indicator {
                    display: none;
                    align-items: center;
                    margin-top: 10px;
                    color: var(--text-color);
                    opacity: 0.7;
                }
                
                .typing-indicator span {
                    height: 8px;
                    width: 8px;
                    margin: 0 2px;
                    background-color: var(--primary-color);
                    border-radius: 50%;
                    display: inline-block;
                    animation: bounce 1.5s infinite ease-in-out;
                }
                
                .typing-indicator span:nth-child(2) {
                    animation-delay: 0.2s;
                }
                
                .typing-indicator span:nth-child(3) {
                    animation-delay: 0.4s;
                }
                
                .feature-buttons {
                    display: flex;
                    margin-top: 10px;
                    gap: 10px;
                    flex-wrap: wrap;
                }
                
                .feature-btn {
                    background: var(--input-bg);
                    border: 1px solid var(--border-color);
                    border-radius: 20px;
                    padding: 8px 15px;
                    font-size: 0.9rem;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    color: var(--text-color);
                    transition: all 0.2s;
                }
                
                .feature-btn:hover {
                    background: var(--primary-light);
                    color: white;
                }
                
                .feature-btn i {
                    margin-right: 5px;
                }
                
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                
                @keyframes bounce {
                    0%, 80%, 100% { transform: translateY(0); }
                    40% { transform: translateY(-10px); }
                }
                
                /* Emoji picker styles */
                .emoji-picker {
                    position: absolute;
                    bottom: 60px;
                    right: 0;
                    background: var(--input-bg);
                    border: 1px solid var(--border-color);
                    border-radius: 10px;
                    padding: 10px;
                    display: none;
                    grid-template-columns: repeat(8, 1fr);
                    gap: 5px;
                    max-width: 300px;
                    box-shadow: 0 5px 15px var(--shadow-color);
                    z-index: 100;
                }
                
                .emoji-btn {
                    font-size: 1.2rem;
                    background: none;
                    border: none;
                    cursor: pointer;
                    padding: 5px;
                    border-radius: 5px;
                    transition: background 0.2s;
                }
                
                .emoji-btn:hover {
                    background: var(--border-color);
                }
                
                /* Responsive styles */
                @media (max-width: 768px) {
                    .message {
                        max-width: 90%;
                    }
                    
                    .feature-buttons {
                        justify-content: center;
                    }
                }
            </style>
        </head>
          <body>
            <div class="header">
                <h2><i class="fas fa-robot"></i> Code Mate Chat</h2>
                <button class="toggle-mode" onclick="toggleTheme()"><i class="fas fa-moon"></i></button>
            </div>
            
		<div id="chat-box">
			${chatHistory.map(msg => `
				<div class="message ${msg.sender}-message">
					${msg.sender === 'assistant' 
						? formatResponse(msg.text)
						: `<p>${escapeHtml(msg.text)}</p>`} <!-- Escape user input -->
				</div>
			`).join('')}
		</div>

            
            <div class="typing-indicator" id="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
            
            <div class="input-container">
                <input type="text" id="query" placeholder="Type a message..." />
                <button class="send-btn" onclick="sendQuery()"><i class="fas fa-paper-plane"></i></button>
                <div class="emoji-picker" id="emoji-picker"></div>
            </div>
            
            <div class="feature-buttons">
                <button class="feature-btn" onclick="toggleEmojiPicker()"><i class="far fa-smile"></i> Emoji</button>
                <button class="feature-btn" onclick="clearChat()"><i class="fas fa-trash"></i> Clear Chat</button>
                <button class="feature-btn" onclick="suggestPrompt('Help me debug')"><i class="fas fa-lightbulb"></i> Debug Help</button>
                <button class="feature-btn" onclick="suggestPrompt('Explain this code')"><i class="fas fa-code"></i> Code Explain</button>
            </div>

            <script>
                const vscode = acquireVsCodeApi();
                let chatHistory = ${JSON.stringify(chatHistory)};
                const emojis = ["😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤗", "🤔", "🤭", "🤫", "🤥", "😶", "😐", "😑", "😬", "🙄", "😯", "😦", "😧", "😮", "😲", "🥱", "😴", "🤤", "😪", "😵", "🤐", "🥴", "🤢", "🤮", "🤧", "😷", "🤒", "🤕"];

                // Initialize emoji picker
                function initEmojiPicker() {
                    const emojiPicker = document.getElementById('emoji-picker');
                    emojis.forEach(emoji => {
                        const btn = document.createElement('button');
                        btn.className = 'emoji-btn';
                        btn.textContent = emoji;
                        btn.onclick = () => addEmoji(emoji);
                        emojiPicker.appendChild(btn);
                    });
                }
                
                initEmojiPicker();

                function toggleEmojiPicker() {
                    const picker = document.getElementById('emoji-picker');
                    picker.style.display = picker.style.display === 'grid' ? 'none' : 'grid';
                }
                
                function addEmoji(emoji) {
                    const queryInput = document.getElementById('query');
                    queryInput.value += emoji;
                    queryInput.focus();
                    document.getElementById('emoji-picker').style.display = 'none';
                }

                function sendQuery() {
                    const query = document.getElementById('query').value;
                    if (!query.trim()) return;
                    
                    // Add user message to chat
                    addMessage(query, 'user');
                    
                    // Show typing indicator
                    document.getElementById('typing-indicator').style.display = 'flex';
                    
                    // Send to VS Code
                    vscode.postMessage({ command: 'sendQuery', text: query });
                    
                    // Clear input
                    document.getElementById('query').value = '';
                }
                
                function addMessage(text, sender) {
                    const chatBox = document.getElementById('chat-box');
                    const messageDiv = document.createElement('div');
                    messageDiv.className = \`message \${sender}-message\`;
                    messageDiv.innerHTML = sender === 'assistant' ? formatResponse(text) : text;
                    chatBox.appendChild(messageDiv);
                    chatBox.scrollTop = chatBox.scrollHeight;
                }
                
                function toggleTheme() {
                    const root = document.documentElement;
                    const isDark = root.getAttribute("data-theme") === "dark";
                    root.setAttribute("data-theme", isDark ? "light" : "dark");
                    
                    const themeIcon = document.querySelector('.toggle-mode i');
                    themeIcon.className = isDark ? "fas fa-moon" : "fas fa-sun";
                }

                function copyCode(text) {
                    navigator.clipboard.writeText(text).then(() => {
                        // Show copy notification
                        const notification = document.createElement('div');
                        notification.textContent = 'Copied to clipboard!';
                        notification.style.position = 'fixed';
                        notification.style.bottom = '20px';
                        notification.style.left = '50%';
                        notification.style.transform = 'translateX(-50%)';
                        notification.style.background = 'var(--primary-color)';
                        notification.style.color = 'white';
                        notification.style.padding = '10px 20px';
                        notification.style.borderRadius = '5px';
                        notification.style.zIndex = '1000';
                        document.body.appendChild(notification);
                        
                        setTimeout(() => {
                            notification.style.opacity = '0';
                            notification.style.transition = 'opacity 0.5s';
                            setTimeout(() => document.body.removeChild(notification), 500);
                        }, 2000);
                    });
                }
                
                function clearChat() {
                    vscode.postMessage({ command: 'clearChat' });
                }
                
                function suggestPrompt(prompt) {
                    if (prompt === 'Explain this code') {
                        vscode.postMessage({ command: 'explainCode' });
                    } else {
                        vscode.postMessage({ command: 'suggestPrompt', prompt });
                    }
                }
                
                // Handle messages from VS Code
                window.addEventListener('message', event => {
                    const message = event.data;
                    
                    if (message.command === 'addResponse') {
                        document.getElementById('typing-indicator').style.display = 'none';
                        addMessage(message.text, 'assistant');
                    } else if (message.command === 'showTypingIndicator') {
                        document.getElementById('typing-indicator').style.display = 'flex';
                    } else if (message.command === 'hideTypingIndicator') {
                        document.getElementById('typing-indicator').style.display = 'none';
                    }
                });
                
                // Add event listener for Enter key
                document.getElementById('query').addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        sendQuery();
                    }
                });
            </script>
        </body>
        </html>
    `;
}
function formatResponse(text: string): string {
    const lines = text.split('\n');
    let insideCodeBlock = false;
    let codeContent = '';
    let formattedText = '';

    lines.forEach(line => {
        if (line.trim().startsWith('```')) {
            if (!insideCodeBlock) {
                // Start of a new code block
                insideCodeBlock = true;
                codeContent = ''; // Reset previous code content
            } else {
                // End of the code block
                insideCodeBlock = false;

                // Escape the code content for safe HTML rendering
                const escapedCode = escapeHtml(codeContent.trim());

                formattedText += `
                    <div class="code-block">
                        <pre><code class="language-python">${escapedCode}</code></pre>
                        <button class="copy-btn" onclick="copyCode(this)"> 
                            <i class="fas fa-copy"></i> Copy
                        </button>
                    </div>
                `;
            }
        } else if (insideCodeBlock) {
            // Collect code lines
            codeContent += line + '\n';
        } else {
            // Regular text (format as paragraph)
            formattedText += `<p>${escapeHtml(line)}</p>`;
        }
    });

    return formattedText;
}

// Escape HTML characters to prevent rendering issues
function escapeHtml(text: string): string {
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

// ✅ FIXED: Properly extract text from the <code> block
function copyCode(buttonElement: HTMLElement): void {
    const codeBlock = buttonElement.previousElementSibling as HTMLElement;
    if (!codeBlock) return;

    const codeElement = codeBlock.querySelector("code");
    if (!codeElement) return;

    const textToCopy = codeElement.innerText.trim(); // Use innerText instead of innerHTML

    navigator.clipboard.writeText(textToCopy).then(() => {
        buttonElement.innerHTML = '<i class="fas fa-check"></i> Copied!';
        setTimeout(() => {
            buttonElement.innerHTML = '<i class="fas fa-copy"></i> Copy';
        }, 2000);
    }).catch((err: any) => {
        console.error("Copy failed", err);
    });
}
